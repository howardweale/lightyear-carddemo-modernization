# CardDemo slice 1 - unsigned receipt

Status: proved-in-ci. Acceptance complete: True.

Source head: fb6154ae1568a0a67a69861f6ca8d51b1e010a72; tested commit: 5ac28347d8fdceb3b50587f1316b46f353871c96.

| Gate | Passed | Evidence |
|---|---|---|
| api-reference | True | {"passed": true, "programs_compared": 6, "programs_required": 6, "interactions": 678, "bms_interactions": 666, "completed_cases": 120, "planned_cases": 120, "case_denominator_status": "complete generated suite", "validated_fields": ["AADDGRP", "ACRCYCR", "ACRCYDB", "ACRDLIM", "ACSADL1", "ACSADL2", "ACSCITY", "ACSEFTC", "ACSFNAM", "ACSGOVT", "ACSHLIM", "ACSLNAM", "ACSMNAM", "ACSPFLG", "ACSPH1A", "ACSPH1B", "ACSPH1C", "ACSPH2A", "ACSPH2B", "ACSPH2C", "ACSSTTE", "ACSTFCO", "ACSTTUS", "ACSZIPC", "ACTSSN1", "ACTSSN2", "ACTSSN3", "ACURBAL", "DOBDAY", "DOBMON", "DOBYEAR", "EXPDAY", "EXPMON", "EXPYEAR", "OPNDAY", "OPNMON", "OPNYEAR", "RISDAY", "RISMON", "RISYEAR"]} |
| browser-reference | True | {"passed": true, "programs_compared": 6, "programs_required": 6, "interactions": 678, "bms_interactions": 666, "completed_cases": 120, "planned_cases": 120, "case_denominator_status": "complete generated suite", "validated_fields": ["AADDGRP", "ACRCYCR", "ACRCYDB", "ACRDLIM", "ACSADL1", "ACSADL2", "ACSCITY", "ACSEFTC", "ACSFNAM", "ACSGOVT", "ACSHLIM", "ACSLNAM", "ACSMNAM", "ACSPFLG", "ACSPH1A", "ACSPH1B", "ACSPH1C", "ACSPH2A", "ACSPH2B", "ACSPH2C", "ACSSTTE", "ACSTFCO", "ACSTTUS", "ACSZIPC", "ACTSSN1", "ACTSSN2", "ACTSSN3", "ACURBAL", "DOBDAY", "DOBMON", "DOBYEAR", "EXPDAY", "EXPMON", "EXPYEAR", "OPNDAY", "OPNMON", "OPNYEAR", "RISDAY", "RISMON", "RISYEAR"]} |
| browser | True | {"passed": true, "interactions": 678, "required": 678} |
| mutation-reference | True | {"passed": true, "programs_compared": 6, "programs_required": 6, "interactions": 678, "bms_interactions": 666, "completed_cases": 120, "planned_cases": 120, "case_denominator_status": "complete generated suite", "validated_fields": ["AADDGRP", "ACRCYCR", "ACRCYDB", "ACRDLIM", "ACSADL1", "ACSADL2", "ACSCITY", "ACSEFTC", "ACSFNAM", "ACSGOVT", "ACSHLIM", "ACSLNAM", "ACSMNAM", "ACSPFLG", "ACSPH1A", "ACSPH1B", "ACSPH1C", "ACSPH2A", "ACSPH2B", "ACSPH2C", "ACSSTTE", "ACSTFCO", "ACSTTUS", "ACSZIPC", "ACTSSN1", "ACTSSN2", "ACTSSN3", "ACURBAL", "DOBDAY", "DOBMON", "DOBYEAR", "EXPDAY", "EXPMON", "EXPYEAR", "OPNDAY", "OPNMON", "OPNYEAR", "RISDAY", "RISMON", "RISYEAR"]} |
| mutation | True | {"passed": true, "killed": 882, "total": 950, "account_input_java": {"AccountInputRules": {"total": 8, "killed": 8, "percent": 100.0, "status_counts": {"KILLED": 8}, "passed": true, "non_killed": []}}, "account_text_money_java": {"AccountTextRules": {"total": 43, "killed": 43, "percent": 100.0, "status_counts": {"KILLED": 43}, "passed": true, "non_killed": []}, "AccountMoneyRule": {"total": 9, "killed": 9, "percent": 100.0, "status_counts": {"KILLED": 9}, "passed": true, "non_killed": []}, "CobolNumber": {"total": 19, "killed": 19, "percent": 100.0, "status_counts": {"KILLED": 19}, "passed": true, "non_killed": []}}, "account_ssn_fico_java": {"AccountSsnRule": {"total": 6, "killed": 6, "percent": 100.0, "status_counts": {"KILLED": 6}, "passed": true, "non_killed": []}, "AccountFicoRule": {"total": 10, "killed": 10, "percent": 100.0, "status_counts": {"KILLED": 10}, "passed": true, "non_killed": []}}, "account_location_java": {"AccountLocationRules": {"total": 2, "killed": 2, "percent": 100.0, "status_counts": {"KILLED": 2}, "passed": true, "non_killed": []}}, "idiomatic_java": {"schema": "carddemo-idiomatic-mutation/1", "program": "COSGN00C", "passed": true, "threshold": 90, "denominator": "all generated mutants per required class; KILLED only", "previous": {"report": "docs/modernization/carddemo-slice-1-evidence-2026-10-18/mutations.xml", "sha256": "949c9a77a5d53b1b2f02b82424c0f18dbb106b387e2e448f0de530e1a60265b9", "classes": {"SignonService": {"total": 35, "killed": 33, "percent": 94.28571428571429, "status_counts": {"KILLED": 33, "SURVIVED": 2}, "passed": true, "non_killed": [{"status": "SURVIVED", "method": "interact", "line": "38", "mutator": "org.pitest.mutationtest.engine.gregor.mutators.VoidMethodCallMutator", "description": "removed call to ai/lightyear/carddemo/Commarea::set"}, {"status": "SURVIVED", "method": "interact", "line": "38", "mutator": "org.pitest.mutationtest.engine.gregor.mutators.VoidMethodCallMutator", "description": "removed call to ai/lightyear/carddemo/Commarea::set"}]}}}, "current": {"SignonService": {"total": 21, "killed": 19, "percent": 90.47619047619048, "status_counts": {"KILLED": 19, "SURVIVED": 2}, "passed": true, "non_killed": [{"status": "SURVIVED", "method": "authenticate", "line": "76", "mutator": "org.pitest.mutationtest.engine.gregor.mutators.VoidMethodCallMutator", "description": "removed call to ai/lightyear/carddemo/Commarea::set"}, {"status": "SURVIVED", "method": "authenticate", "line": "78", "mutator": "org.pitest.mutationtest.engine.gregor.mutators.VoidMethodCallMutator", "description": "removed call to ai/lightyear/carddemo/Commarea::set"}]}, "SignonRules": {"total": 15, "killed": 15, "percent": 100.0, "status_counts": {"KILLED": 15}, "passed": true, "non_killed": []}}, "remaining_statement_engine_programs": ["COACTVWC", "COACTUPC", "COPAUS0C", "COPAUS1C"]}, "percent": 92.84210526315789, "threshold": 90, "missing_screen_handlers": [], "status_counts": {"KILLED": 882, "SURVIVED": 50, "NO_COVERAGE": 17, "TIMED_OUT": 1}, "denominator": "every PIT mutation in configured screen-handler/helper scope; timeout, no-coverage and errors are not counted killed", "report": {"path": "work/carddemo-proof-artifacts/carddemo-proof-mutation/pit-reports/mutations.xml", "sha256": "6b10c52843cf4c427debd495d140370d4dcb7cbacc017643fbfd75a33a311f33"}} |
| ci-jobs | True | {"passed": true} |

Remaining evidence gaps: 

Quirks:
- Additional hand-specified language/routing contracts and mocked master READ-miss tests supplement independent raw-source real-PostgreSQL replay; they do not generate scenario expectations
- COPAUS0C selection XCTL preserves page count and pagination history before GATHER-DETAILS
- COACTUPC retains the requested account key in old details before a failed cross-reference read
- COMEN01C first entry sets reentry context before returning its menu screen
- API, browser and Java replay compare complete returned COMMAREA bytes; SEND TEXT has no token and raw source faults have no proved RETURN state
- COSGN00C uses fresh working storage and retains uppercase submitted user ID after error SENDs
- Record rewrites preserve explicit no-sign and non-negative-zero encoding metadata for unsigned DISPLAY and binary numeric fields
- AUTHFRDS fixed PIC X SQL hosts retain padding; VARCHAR follows its explicit length; PostgreSQL JSON timestamp spelling removes only fractional trailing zeros without losing microseconds
- PAUTDTL1 uses the pinned DBD unique PAUT9CTS ascending byte-key sequence within each parent; synthetic insertion/twin ordinals remain provenance, not traversal order
- Complete expected database states are content-addressed JSON files; browser and Java replay verify SHA-256 and compare every table and row after every interaction
- Numeric DISPLAY condition names preserve invalid and LOW-VALUES bytes under the disclosed EBCDIC comparison bound until source validation
- COPAUS2C fraud removal retains the AUTHFRDS audit row with AUTH_FRAUD=R through duplicate-insert UPDATE; it does not delete the row
- Blank submitted group becomes LOW-VALUES and differs from stored spaces; post-commit resubmission preserves this behavior, while a separate synthetic PROOFGRP account retains strict no-change/no-error/no-write assertions
- Visible terminal nulls project to blank cells; reference case artifacts retain exact symbolic-output hex and first-byte null selection
- Positive update inputs explicitly use synthetic SSN 123-45-6789, OR/97001 and phone 2 (206)555-0102; original public fixture bytes and invalid cases remain preserved
- COACTUPC account rewrite omits ZIP, preserved as source behavior
- COMEN01 invalid option emits an error then faults on a table subscript; compare the emitted frame and database, discard that session, and make no continuation claim
- BMS external constants use private symbolic bytes, not a native 3270 wire encoding
- CSUTLDTC executes from pinned source; its CEEDAYS port models documented Gregorian YYYYMMDD feedback and Lilian epoch; native LE execution remains absent
- SEND TEXT terminal responses have no BMS fields; complete text and ended state are compared
- Menu options 3-10 route to one not-in-this-slice endpoint; those destination services and their screens are excluded, and boundary interactions are counted separately

Out of scope:
- other fifteen maps and their services
- native CICS, IMS and DB2 execution
- production unloads or production data
- release or z/OS acceptance
- real signatures, import, activation or Phase 2

Prepared as an unsigned Factory review request for Howard. No signature, import, activation or Phase 2 authority.

JSON SHA-256: a89deeccc0b98ef3c78275d9edffee4e7d377947a5d2227df0c3d630b4955890
