package org.idempiere.test;

import static org.junit.jupiter.api.Assertions.*;

import java.math.BigDecimal;
import java.nio.file.Files;
import java.nio.file.Path;
import java.sql.Timestamp;
import java.util.Properties;

import org.compiere.acct.DocManager;
import org.compiere.model.*;
import org.compiere.process.DocAction;
import org.compiere.process.ProcessInfo;
import org.compiere.util.*;
import org.compiere.wf.MWorkflow;
import org.junit.jupiter.api.Test;

/** Observed native partial-invoicing journey. */
public class LightyearPartialInvoiceTest extends AbstractTestCase {
    private final Properties evidence = new Properties();
    private final Timestamp businessDate = Timestamp.valueOf("2026-09-26 00:00:00");
    private final Timestamp shipDate = Timestamp.valueOf("2026-09-26 12:34:56.123456");

    private void fact(String key, Object value) {
        evidence.setProperty(key, String.valueOf(value));
    }

    private void record(String name, PO model) {
        fact(name + ".id", model.get_ID());
        fact(name + ".uuid", model.get_UUID());
        fact(name + ".saved", true);
    }

    private void stage(String name, PO model) {
        model.load(getTrxName());
        record(name, model);
        fact(name + ".status", model.get_ValueAsString("DocStatus"));
    }

    private void complete(String name, PO model) {
        ProcessInfo result = MWorkflow.runDocumentActionWorkflow(model, DocAction.ACTION_Complete);
        assertNotNull(result, name + ": missing workflow result");
        assertFalse(result.isError(), name + ": " + result.getSummary());
        stage(name, model);
        assertEquals(DocAction.STATUS_Completed, model.get_ValueAsString("DocStatus"),
            name + ": workflow did not complete");
    }

    private void post(PO model, MAcctSchema[] schemas) {
        model.load(getTrxName());
        assertTrue(model.get_ValueAsBoolean("Processed"), "Posting requires a processed document");
        if (!"Y".equals(model.get_ValueAsString("Posted"))) {
            // Explicitly disable reposting: no accounting deletion or history creation.
            String error = DocManager.postDocument(schemas, model.get_Table_ID(), model.get_ID(),
                false, false, false, getTrxName());
            assertNull(error, "Posting failed for " + model.get_TableName() + ": " + error);
        }
        model.load(getTrxName());
        assertEquals("Y", model.get_ValueAsString("Posted"),
            "Document was not posted: " + model.get_TableName());
    }

    private MInOut ship(String name, MOrder order, MOrderLine orderLine, BigDecimal quantity) {
        MInOut shipment = new MInOut(order, DictionaryIDs.C_DocType.MM_SHIPMENT.id, businessDate);
        shipment.setDateAcct(businessDate);
        shipment.setShipDate(shipDate);
        fact(name + ".shipDate.input", shipDate);
        shipment.saveEx();
        MInOutLine line = new MInOutLine(shipment);
        line.setOrderLine(orderLine, DictionaryIDs.M_Locator.HQ.id, quantity);
        line.setQty(quantity);
        line.saveEx();
        complete(name, shipment);
        fact(name + ".shipDate.readback", shipment.getShipDate());
        return shipment;
    }

    private MInvoice invoice(String name, MInOut shipment, BigDecimal quantity) {
        MInOutLine[] shipmentLines = shipment.getLines(false);
        assertEquals(1, shipmentLines.length, "Expected the single created shipment line");
        MInvoice invoice = new MInvoice(shipment, businessDate);
        invoice.setDateAcct(businessDate);
        invoice.saveEx();
        MInvoiceLine line = new MInvoiceLine(invoice);
        line.setShipLine(shipmentLines[0]);
        line.setQty(quantity);
        line.saveEx();
        complete(name, invoice);
        fact(name + ".total", invoice.getGrandTotal());
        fact(name + ".net", invoice.getTotalLines());
        return invoice;
    }

    private MPayment pay(String name, MBPartner customer, MInvoice invoice, int bank) {
        invoice.load(getTrxName());
        MPayment payment = new MPayment(Env.getCtx(), 0, getTrxName());
        payment.setC_DocType_ID(true);
        payment.setC_BankAccount_ID(bank);
        payment.setC_BPartner_ID(customer.get_ID());
        payment.setC_Invoice_ID(invoice.get_ID());
        payment.setDateTrx(businessDate);
        payment.setDateAcct(businessDate);
        payment.setTenderType(MPayment.TENDERTYPE_DirectDeposit);
        payment.setC_Currency_ID(invoice.getC_Currency_ID());
        payment.setPayAmt(invoice.getGrandTotal());
        payment.saveEx();
        complete(name, payment);
        fact(name + ".amount", payment.getPayAmt());
        return payment;
    }

    private void postSettlement(MInvoice invoice, MPayment payment, MAcctSchema[] schemas) {
        post(invoice, schemas);
        post(payment, schemas);
        MAllocationHdr[] allocations = MAllocationHdr.getOfInvoice(
            Env.getCtx(), invoice.get_ID(), getTrxName());
        assertTrue(allocations.length > 0, "Payment workflow did not create an allocation");
        for (MAllocationHdr allocation : allocations) {
            allocation.load(getTrxName());
            assertEquals(DocAction.STATUS_Completed, allocation.getDocStatus(),
                "Payment allocation did not complete");
            post(allocation, schemas);
        }
    }

    private void observeSettlement(String invoiceName, MInvoice invoice,
            String paymentName, MPayment payment) {
        stage(invoiceName, invoice);
        fact(invoiceName + ".total", invoice.getGrandTotal());
        fact(invoiceName + ".net", invoice.getTotalLines());
        fact(invoiceName + ".paid", invoice.isPaid());
        fact(invoiceName + ".posted", invoice.get_ValueAsString("Posted"));
        stage(paymentName, payment);
        fact(paymentName + ".amount", payment.getPayAmt());
        fact(paymentName + ".posted", payment.get_ValueAsString("Posted"));
        MAllocationHdr[] allocations = MAllocationHdr.getOfInvoice(
            Env.getCtx(), invoice.get_ID(), getTrxName());
        boolean allPosted = allocations.length > 0;
        boolean allCompleted = allocations.length > 0;
        for (MAllocationHdr allocation : allocations) {
            allocation.load(getTrxName());
            allPosted &= "Y".equals(allocation.get_ValueAsString("Posted"));
            allCompleted &= DocAction.STATUS_Completed.equals(allocation.getDocStatus());
        }
        fact(paymentName + ".allocations", allocations.length);
        fact(paymentName + ".allocationsPosted", allPosted);
        fact(paymentName + ".allocationsCompleted", allCompleted);
    }

    @Test
    public void partialInvoicingToSeparatePayments() throws Exception {
        Path output = Path.of(System.getProperty("lightyear.output"));
        fact("status", "started");
        fact("database", DB.isOracle() ? "oracle" : "postgresql");
        try {
            Properties ctx = Env.getCtx();
            String trx = getTrxName();
            int issuesBefore = DB.getSQLValueEx(trx, "SELECT COUNT(*) FROM AD_Issue");
            MAcctSchema[] schemas = MAcctSchema.getClientAcctSchema(ctx, getAD_Client_ID());
            assertTrue(schemas.length > 0, "Client has no accounting schema");

            MBPartner template = new MBPartner(ctx, DictionaryIDs.C_BPartner.JOE_BLOCK.id, trx);
            MBPartner customer = new MBPartner(ctx, 0, trx);
            customer.setValue("LY-PARTIAL-INVOICE");
            customer.setName("Caf\u00e9 \u6771\u4eac \u0141\u00f3d\u017a");
            customer.setDescription("");
            fact("customer.name.input", customer.getName());
            fact("customer.description.input", "empty-string");
            customer.setIsCustomer(true);
            customer.setC_BP_Group_ID(template.getC_BP_Group_ID());
            customer.setM_PriceList_ID(template.getM_PriceList_ID());
            customer.setC_PaymentTerm_ID(template.getC_PaymentTerm_ID());
            customer.setPaymentRule(MBPartner.PAYMENTRULE_OnCredit);
            customer.saveEx();
            record("customer", customer);

            MBPartnerLocation[] templateLocations = template.getLocations(false);
            assertTrue(templateLocations.length > 0, "Template customer has no location");
            MBPartnerLocation location = new MBPartnerLocation(ctx, 0, trx);
            location.setC_BPartner_ID(customer.get_ID());
            location.setC_Location_ID(templateLocations[0].getC_Location_ID());
            location.setName("Evaluation location");
            location.setIsBillTo(true);
            location.setIsShipTo(true);
            location.saveEx();
            record("customerLocation", location);
            commit();

            MProduct product = new MProduct(ctx, 0, trx);
            product.setValue("LY-PARTIAL-INVOICE");
            product.setName("Lightyear Partial Invoice Product");
            product.setM_Product_Category_ID(DictionaryIDs.M_Product_Category.STANDARD.id);
            product.setProductType(MProduct.PRODUCTTYPE_Item);
            product.setIsStocked(true);
            product.setIsSold(true);
            product.setIsPurchased(true);
            product.setC_UOM_ID(DictionaryIDs.C_UOM.EACH.id);
            product.setC_TaxCategory_ID(DictionaryIDs.C_TaxCategory.STANDARD.id);
            product.saveEx();
            record("product", product);
            commit();

            MInventory inventory = new MInventory(ctx, 0, trx);
            inventory.setM_Warehouse_ID(getM_Warehouse_ID());
            inventory.setMovementDate(businessDate);
            inventory.setDateAcct(businessDate);
            inventory.setC_DocType_ID(DictionaryIDs.C_DocType.MATERIAL_PHYSICAL_INVENTORY.id);
            inventory.saveEx();
            MInventoryLine inventoryLine = new MInventoryLine(inventory, DictionaryIDs.M_Locator.HQ.id,
                product.get_ID(), 0, BigDecimal.ZERO, new BigDecimal("10"));
            inventoryLine.saveEx();
            complete("openingInventory", inventory);
            commit();

            MOrder order = new MOrder(ctx, 0, trx);
            order.setIsSOTrx(true);
            order.setBPartner(customer);
            order.setC_BPartner_Location_ID(location.get_ID());
            order.setBill_Location_ID(location.get_ID());
            order.setM_Warehouse_ID(getM_Warehouse_ID());
            order.setC_DocTypeTarget_ID(MOrder.DocSubTypeSO_Standard);
            order.setDateOrdered(businessDate);
            order.setDatePromised(businessDate);
            order.setDateAcct(businessDate);
            order.setDeliveryRule(MOrder.DELIVERYRULE_CompleteOrder);
            order.setPaymentRule(MOrder.PAYMENTRULE_OnCredit);
            order.saveEx();
            MPriceListVersion version = MPriceList.get(ctx, order.getM_PriceList_ID(), trx)
                .getPriceListVersion(businessDate);
            assertNotNull(version, "No applicable price list version");
            MProductPrice price = new MProductPrice(ctx, version.get_ID(), product.get_ID(), trx);
            price.setPriceList(new BigDecimal("19.995"));
            price.setPriceStd(new BigDecimal("17.9955"));
            price.setPriceLimit(BigDecimal.ZERO);
            price.saveEx();
            record("productPrice", price);
            commit();

            MOrderLine orderLine = new MOrderLine(order);
            orderLine.setLine(10);
            orderLine.setProduct(product);
            orderLine.setQty(new BigDecimal("3"));
            orderLine.setPriceList(new BigDecimal("19.995"));
            orderLine.setPrice(new BigDecimal("17.9955"));
            orderLine.setDatePromised(businessDate);
            orderLine.setC_Tax_ID(DictionaryIDs.C_Tax.PST.id);
            orderLine.saveEx();
            complete("order", order);
            commit();
            orderLine.load(trx);
            fact("order.reserved", orderLine.getQtyReserved());
            fact("order.priceList", orderLine.getPriceList());
            fact("order.priceActual", orderLine.getPriceActual());
            fact("order.discount", orderLine.getDiscount());
            fact("order.taxId", orderLine.getC_Tax_ID());
            fact("order.taxRate", new MTax(ctx, orderLine.getC_Tax_ID(), trx).getRate());

            int bank = DB.getSQLValueEx(trx,
                "SELECT C_BankAccount_ID FROM C_BankAccount WHERE AD_Client_ID=? AND IsDefault='Y'",
                getAD_Client_ID());
            assertTrue(bank > 0, "Client has no default bank account");
            BigDecimal firstQuantity = new BigDecimal("1");
            MInOut firstShipment = ship("firstShipment", order, orderLine, firstQuantity);
            MInvoice firstInvoice = invoice("firstInvoice", firstShipment, firstQuantity);
            MPayment firstPayment = pay("firstPayment", customer, firstInvoice, bank);
            postSettlement(firstInvoice, firstPayment, schemas);
            commit();
            orderLine.load(trx);
            fact("invoicing.afterFirst", orderLine.getQtyInvoiced());
            observeSettlement("firstInvoice", firstInvoice, "firstPayment", firstPayment);

            order.load(trx);
            BigDecimal remainingQuantity = new BigDecimal("2");
            MInOut shipment = ship("shipment", order, orderLine, remainingQuantity);
            MInvoice invoice = invoice("invoice", shipment, remainingQuantity);
            MPayment payment = pay("payment", customer, invoice, bank);
            postSettlement(invoice, payment, schemas);
            getTrx().commit(true);

            customer.load(trx);
            record("customer", customer);
            fact("customer.name.readback", customer.getName());
            fact("customer.description.readback",
                customer.getDescription() == null ? "SQL-NULL" : customer.getDescription());
            location.load(trx);
            record("customerLocation", location);
            product.load(trx);
            record("product", product);
            price.load(trx);
            record("productPrice", price);
            stage("openingInventory", inventory);
            inventoryLine.load(trx);
            fact("openingInventory.quantity", inventoryLine.getQtyCount());
            stage("order", order);
            fact("order.total", order.getGrandTotal());
            fact("order.net", order.getTotalLines());
            stage("firstShipment", firstShipment);
            fact("firstShipment.shipDate.readback", firstShipment.getShipDate());
            stage("shipment", shipment);
            fact("shipment.shipDate.readback", shipment.getShipDate());
            observeSettlement("firstInvoice", firstInvoice, "firstPayment", firstPayment);
            observeSettlement("invoice", invoice, "payment", payment);
            orderLine.load(trx);
            fact("invoicing.final", orderLine.getQtyInvoiced());
            fact("shipment.delivered", orderLine.getQtyDelivered());
            fact("inventory.onHand", DB.getSQLValueBDEx(trx,
                "SELECT SUM(QtyOnHand) FROM M_StorageOnHand WHERE M_Product_ID=?", product.get_ID()));
            fact("inventory.movements", DB.getSQLValueEx(trx,
                "SELECT COUNT(*) FROM M_Transaction WHERE M_Product_ID=?", product.get_ID()));
            int issuesAfter = DB.getSQLValueEx(trx, "SELECT COUNT(*) FROM AD_Issue");
            fact("newIssueCount", issuesAfter - issuesBefore);
            fact("status", "completed-and-committed");
        } catch (Exception | AssertionError failure) {
            fact("status", "failed");
            fact("failure", failure.toString());
            throw failure;
        } finally {
            try (var out = Files.newOutputStream(output)) {
                evidence.storeToXML(out, "Observed iDempiere partial-invoicing journey");
            }
        }
    }
}
